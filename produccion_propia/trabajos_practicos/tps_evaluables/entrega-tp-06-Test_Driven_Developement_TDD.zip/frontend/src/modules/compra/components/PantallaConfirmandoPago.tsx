import { LoaderCircle } from 'lucide-react';

// Se ve un instante al volver de Mercado Pago, mientras el backend informa el estado del pago.
export const PantallaConfirmandoPago = () => (
  <section className="mx-auto flex min-h-[calc(100dvh-3.5rem)] max-w-md flex-col justify-center px-4 py-10">
    <div className="rounded-md bg-superficie p-6 text-center" aria-live="polite">
      <LoaderCircle aria-hidden className="mx-auto size-12 animate-spin text-secundario" />
      <h1 tabIndex={-1} className="mt-4 text-xl font-bold outline-none">
        Confirmando tu pago…
      </h1>
      <p className="mt-1.5 text-[15px] text-tinta-suave">Estamos consultando a Mercado Pago.</p>
    </div>
  </section>
);
