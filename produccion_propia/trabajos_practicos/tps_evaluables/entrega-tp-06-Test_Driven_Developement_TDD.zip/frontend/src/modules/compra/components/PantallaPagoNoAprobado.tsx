import { CircleX } from 'lucide-react';
import { Boton } from '../../../shared/ui/Boton';
import { formatearTotal } from '../../../shared/ui/formato';
import type { ResultadoVisible } from '../useCompra';
import { codigoCorto } from './Sello';

interface PantallaPagoNoAprobadoProps {
  resultado: ResultadoVisible;
  alComprarOtra: () => void;
}

// Vuelta de Mercado Pago sin pago aprobado: no hay cobro ni mail, y las entradas no quedan reservadas.
export const PantallaPagoNoAprobado = ({
  resultado,
  alComprarOtra,
}: PantallaPagoNoAprobadoProps) => {
  const rechazado = resultado.estadoPago === 'RECHAZADO';

  return (
    <section className="mx-auto flex min-h-[calc(100dvh-3.5rem)] max-w-md flex-col justify-center px-4 py-10">
      <div className="rounded-md bg-superficie p-6 text-center">
        <CircleX aria-hidden className="mx-auto size-14 text-alerta" strokeWidth={1.75} />
        <h1 tabIndex={-1} className="mt-3 text-[26px] font-bold text-alerta outline-none">
          {rechazado ? 'Pago rechazado' : 'Pago sin confirmar'}
        </h1>
        <p className="mt-1.5 text-[15px] text-tinta-suave">
          {rechazado
            ? 'Mercado Pago rechazó el pago. No se te cobró nada y las entradas no quedaron reservadas.'
            : 'Mercado Pago todavía no confirmó el pago. Si no lo completaste, podés volver a comprar.'}
        </p>
        <dl className="mt-5 border-t border-renglon text-left text-[15px]">
          <div className="flex justify-between border-b border-renglon py-2.5">
            <dt className="text-tinta-suave">Importe</dt>
            <dd className="font-bold cifras">{formatearTotal(resultado.total)}</dd>
          </div>
          <div className="flex justify-between border-b border-renglon py-2.5">
            <dt className="text-tinta-suave">Orden</dt>
            <dd className="font-bold cifras">{codigoCorto(resultado.numeroOrden)}</dd>
          </div>
        </dl>
        <Boton ancho className="mt-6" onClick={alComprarOtra}>
          Volver a comprar
        </Boton>
      </div>
    </section>
  );
};
