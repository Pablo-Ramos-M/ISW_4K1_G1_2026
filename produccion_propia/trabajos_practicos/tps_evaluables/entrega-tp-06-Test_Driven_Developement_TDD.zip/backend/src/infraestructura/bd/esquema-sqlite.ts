import type { DatabaseSync } from 'node:sqlite';

// Se usa al crear la tabla y al migrar bases creadas antes de que existiera la columna.
const COLUMNA_ESTADO_PAGO = `estado_pago TEXT NOT NULL DEFAULT 'PENDIENTE'
      CHECK (estado_pago IN ('PENDIENTE', 'APROBADO', 'RECHAZADO'))`;

const ESQUEMA = `
  CREATE TABLE IF NOT EXISTS usuarios (
    email TEXT PRIMARY KEY
  );

  CREATE TABLE IF NOT EXISTS compras (
    numero_orden TEXT PRIMARY KEY,
    email TEXT NOT NULL,
    fecha_visita TEXT NOT NULL,
    forma_pago TEXT NOT NULL CHECK (forma_pago IN ('EFECTIVO', 'TARJETA')),
    total INTEGER NOT NULL CHECK (total >= 0),
    ${COLUMNA_ESTADO_PAGO},
    FOREIGN KEY (email) REFERENCES usuarios(email)
  );

  CREATE TABLE IF NOT EXISTS entradas (
    numero_orden TEXT NOT NULL,
    edad INTEGER NOT NULL CHECK (edad >= 0),
    tipo_pase TEXT NOT NULL CHECK (tipo_pase IN ('VIP', 'REGULAR')),
    precio INTEGER NOT NULL CHECK (precio >= 0),
    FOREIGN KEY (numero_orden) REFERENCES compras(numero_orden) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_compras_email_fecha
    ON compras(email, fecha_visita);
  CREATE INDEX IF NOT EXISTS idx_entradas_numero_orden
    ON entradas(numero_orden);
`;

const tieneColumna = (baseDatos: DatabaseSync, tabla: string, columna: string): boolean =>
  (baseDatos.prepare(`PRAGMA table_info(${tabla})`).all() as { name: string }[]).some(
    (fila) => fila.name === columna,
  );

const migrar = (baseDatos: DatabaseSync): void => {
  if (!tieneColumna(baseDatos, 'compras', 'estado_pago')) {
    baseDatos.exec(`ALTER TABLE compras ADD COLUMN ${COLUMNA_ESTADO_PAGO}`);
  }
};

export const aplicarEsquema = (baseDatos: DatabaseSync): void => {
  baseDatos.exec(ESQUEMA);
  migrar(baseDatos);
};
