// La fecha de visita es un día de calendario: viaja y se guarda como `AAAA-MM-DD`,
// a partir de sus partes locales, para que no se corra según la zona horaria.

const dosDigitos = (numero: number): string => String(numero).padStart(2, '0');

export const formatearFechaIso = (fecha: Date): string =>
  `${fecha.getFullYear()}-${dosDigitos(fecha.getMonth() + 1)}-${dosDigitos(fecha.getDate())}`;

export const leerFechaIso = (texto: string): Date => {
  const [anio, mes, dia] = texto.split('-').map(Number);
  return new Date(anio!, mes! - 1, dia);
};
