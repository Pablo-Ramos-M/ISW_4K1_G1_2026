import { randomUUID } from 'node:crypto';
import type { ConexionSqlite } from '../../infraestructura/bd/conexion-sqlite';
import type { FormaPago, Subtotal, TipoPase } from '../pagos/pagos.types';
import type { CompraRegistrada, EstadoPagoCompra, NuevaCompra } from './compras.types';
import { formatearFechaIso, leerFechaIso } from '../../shared/fechas';
import { PREFIJO_ORDEN } from './compras.constants';

// Alias (no interfaz): node:sqlite devuelve filas como Record y solo un alias se puede convertir.
type FilaCompra = {
  email: string;
  fecha_visita: string;
  forma_pago: FormaPago;
  estado_pago: EstadoPagoCompra;
  total: number;
};

type FilaEntrada = {
  edad: number;
  tipo_pase: TipoPase;
  precio: number;
};

const aSubtotal = (fila: FilaEntrada): Subtotal => ({
  edad: fila.edad,
  tipoPase: fila.tipo_pase,
  precio: fila.precio,
});

const PAGO_RECHAZADO: EstadoPagoCompra = 'RECHAZADO';

export class SqliteComprasRepository {
  constructor(private readonly conexion: ConexionSqlite) {}

  // Un pago rechazado libera las entradas: no cuentan para el máximo por fecha.
  async contarEntradas(email: string, fecha: Date): Promise<number> {
    const fechaSql = formatearFechaIso(fecha);
    const fila = this.conexion.baseDatos
      .prepare(
        `SELECT COUNT(*) cantidad
         FROM entradas e
         JOIN compras c ON c.numero_orden = e.numero_orden
         WHERE c.email = ? AND c.fecha_visita = ? AND c.estado_pago <> ?`,
      )
      .get(email, fechaSql, PAGO_RECHAZADO) as { cantidad: number };

    return fila.cantidad;
  }

  async guardar(compra: NuevaCompra): Promise<string> {
    const numeroOrden = `${PREFIJO_ORDEN}${randomUUID()}`;
    const fechaSql = formatearFechaIso(compra.fechaVisita);
    const baseDatos = this.conexion.baseDatos;

    baseDatos.exec('BEGIN');
    try {
      baseDatos
        .prepare(
          `INSERT INTO compras
             (numero_orden, email, fecha_visita, forma_pago, total)
           VALUES (?, ?, ?, ?, ?)`,
        )
        .run(numeroOrden, compra.email, fechaSql, compra.formaPago, compra.detalle.total);

      const insertarEntrada = baseDatos.prepare(
        `INSERT INTO entradas (numero_orden, edad, tipo_pase, precio)
         VALUES (?, ?, ?, ?)`,
      );
      for (const subtotal of compra.detalle.subtotales) {
        insertarEntrada.run(numeroOrden, subtotal.edad, subtotal.tipoPase, subtotal.precio);
      }

      baseDatos.exec('COMMIT');
      return numeroOrden;
    } catch (error) {
      baseDatos.exec('ROLLBACK');
      throw error;
    }
  }

  async buscar(numeroOrden: string): Promise<CompraRegistrada | undefined> {
    const compra = this.conexion.baseDatos
      .prepare(
        `SELECT email, fecha_visita, forma_pago, estado_pago, total
         FROM compras WHERE numero_orden = ?`,
      )
      .get(numeroOrden) as FilaCompra | undefined;
    if (!compra) return undefined;

    return {
      numeroOrden,
      email: compra.email,
      fechaVisita: leerFechaIso(compra.fecha_visita),
      formaPago: compra.forma_pago,
      estadoPago: compra.estado_pago,
      detalle: { subtotales: this.buscarEntradas(numeroOrden), total: compra.total },
    };
  }

  // `rowid` conserva el orden de carga: de él sale la numeración de los QR.
  private buscarEntradas(numeroOrden: string): Subtotal[] {
    const filas = this.conexion.baseDatos
      .prepare('SELECT edad, tipo_pase, precio FROM entradas WHERE numero_orden = ? ORDER BY rowid')
      .all(numeroOrden) as FilaEntrada[];
    return filas.map(aSubtotal);
  }

  async actualizarEstadoPago(numeroOrden: string, estado: EstadoPagoCompra): Promise<void> {
    this.conexion.baseDatos
      .prepare('UPDATE compras SET estado_pago = ? WHERE numero_orden = ?')
      .run(estado, numeroOrden);
  }
}
