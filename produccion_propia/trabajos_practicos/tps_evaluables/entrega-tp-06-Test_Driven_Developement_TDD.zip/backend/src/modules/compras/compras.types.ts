import type {
  DetallePrecio,
  FormaPago,
  ResultadoPago,
  Subtotal,
  Visitante,
} from '../pagos/pagos.types';

export interface SolicitudCompra {
  email: string;
  fechaVisita: Date;
  cantidad: number;
  visitantes: Visitante[];
  formaPago: FormaPago;
}

export interface NuevaCompra {
  email: string;
  fechaVisita: Date;
  visitantes: Visitante[];
  formaPago: FormaPago;
  detalle: DetallePrecio;
}

// Con tarjeta, la compra queda PENDIENTE hasta que Mercado Pago aprueba o rechaza el pago.
export type EstadoPagoCompra = 'PENDIENTE' | 'APROBADO' | 'RECHAZADO';

// Una compra tal como quedó guardada, con su número de orden y el estado del pago.
export interface CompraRegistrada {
  numeroOrden: string;
  email: string;
  fechaVisita: Date;
  formaPago: FormaPago;
  estadoPago: EstadoPagoCompra;
  detalle: DetallePrecio;
}

// Cada entrada lleva su propio QR de acceso.
export interface EntradaConfirmada extends Subtotal {
  codigoQR: string;
}

export interface ResumenCompra {
  numeroOrden: string;
  fechaVisita: Date;
  cantidadEntradas: number;
  formaPago: FormaPago;
  detalle: DetallePrecio;
  entradas: EntradaConfirmada[];
}

export interface ResultadoCompra {
  numeroOrden: string;
  cantidadEntradas: number;
  fechaVisita: Date;
  total: number;
  pago: ResultadoPago;
}

// Lo que necesita el front para mostrar el resultado al volver de Mercado Pago.
export interface ConsultaCompra {
  numeroOrden: string;
  cantidadEntradas: number;
  fechaVisita: Date;
  total: number;
  formaPago: FormaPago;
  estadoPago: EstadoPagoCompra;
}

// Colaboradores inyectados por constructor. Se agregan a medida que los tests los piden.
export interface DependenciasCompras {
  usuarios: {
    estaRegistrado(email: string): Promise<boolean>;
  };
  parque: {
    validarFechaVisita(fechaVisita: Date, ahora?: Date): void;
  };
  pagos: {
    calcularDetalle(visitantes: Visitante[]): DetallePrecio;
    procesarPago(numeroOrden: string, total: number, formaPago: FormaPago): Promise<ResultadoPago>;
  };
  compras: {
    contarEntradas(email: string, fecha: Date): Promise<number>;
    guardar(compra: NuevaCompra): Promise<string>;
    buscar(numeroOrden: string): Promise<CompraRegistrada | undefined>;
    actualizarEstadoPago(numeroOrden: string, estado: EstadoPagoCompra): Promise<void>;
  };
  notificador: {
    enviarConfirmacion(email: string, resumen: ResumenCompra): Promise<void>;
  };
}
