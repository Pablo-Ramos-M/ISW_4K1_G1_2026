import type { PreferenciaSimulada } from './pagos.types';

// Resultado que elige el comprador en el checkout simulado.
export const RESULTADO_CHECKOUT_APROBADO = 'aprobado';
export const RESULTADO_CHECKOUT_RECHAZADO = 'rechazado';

const FORMATO_PESOS = new Intl.NumberFormat('es-AR', {
  style: 'currency',
  currency: 'ARS',
  maximumFractionDigits: 0,
});

const ENTIDADES_HTML: Record<string, string> = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
};

const escaparHtml = (texto: string): string =>
  texto.replace(/[&<>"']/g, (caracter) => ENTIDADES_HTML[caracter]!);

const armarAccion = (urlPagar: string, idPreferencia: string, resultado: string): string =>
  escaparHtml(`${urlPagar}?${new URLSearchParams({ pref_id: idPreferencia, resultado })}`);

// Paleta de CONVENCIONES.md §1.1, con los mismos tokens que el front: el botón principal en verde
// oscuro y el de cancelar en rojo tierra. Los colores se declaran una sola vez, en :root.
const ESTILOS = `
  :root {
    --color-primario: #386641; --color-alerta: #bc4749; --color-fondo: #f2e8cf;
    --color-superficie: #ffffff; --color-renglon: #e3d8ba; --color-tinta: #1f3a25;
    --color-tinta-suave: #4b5a44;
  }
  body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 16px;
    box-sizing: border-box; background: var(--color-fondo); color: var(--color-tinta);
    font-family: Lato, system-ui, sans-serif; }
  main { width: 100%; max-width: 28rem; background: var(--color-superficie); border-radius: 6px;
    padding: 24px; }
  .marca { margin: -24px -24px 24px; padding: 12px 24px; border-bottom: 1px solid var(--color-renglon);
    font-size: 14px; font-weight: 700; color: var(--color-tinta-suave); }
  h1 { margin: 0; font-size: 20px; }
  dl { margin: 20px 0 0; border-top: 1px solid var(--color-renglon); font-size: 15px; }
  dl div { display: flex; justify-content: space-between; gap: 12px; padding: 10px 0;
    border-bottom: 1px solid var(--color-renglon); }
  dt { color: var(--color-tinta-suave); }
  dd { margin: 0; font-weight: 700; word-break: break-all; text-align: right; }
  form { margin: 12px 0 0; }
  button { width: 100%; min-height: 48px; border-radius: 6px; font: inherit; font-size: 17px;
    font-weight: 700; cursor: pointer; }
  .pagar { margin-top: 24px; border: 0; background: var(--color-primario);
    color: var(--color-superficie); }
  .rechazar { border: 2px solid var(--color-alerta); background: var(--color-superficie);
    color: var(--color-alerta); }
  .aviso { margin: 16px 0 0; text-align: center; font-size: 13px; color: var(--color-tinta-suave); }
`;

const armarPagina = (contenido: string): string => `<!doctype html>
<html lang="es-AR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mercado Pago (simulación)</title>
<style>${ESTILOS}</style>
</head>
<body>
<main>
<p class="marca">Mercado Pago (simulación)</p>
${contenido}
<p class="aviso">Simulación para el TP: no se realiza ningún cobro.</p>
</main>
</body>
</html>
`;

// Página que reemplaza al checkout de Mercado Pago (FAQ 4): no se realiza ningún cobro.
export const renderizarCheckoutSimulado = (
  preferencia: PreferenciaSimulada,
  urlPagar: string,
): string =>
  armarPagina(`<h1>Pagá tu compra en EcoHarmony Park</h1>
<dl>
  <div><dt>Total a pagar</dt><dd>${escaparHtml(FORMATO_PESOS.format(preferencia.total))}</dd></div>
  <div><dt>Orden</dt><dd>${escaparHtml(preferencia.numeroOrden)}</dd></div>
</dl>
<form method="post" action="${armarAccion(urlPagar, preferencia.id, RESULTADO_CHECKOUT_APROBADO)}">
  <button type="submit" class="pagar">Pagar</button>
</form>
<form method="post" action="${armarAccion(urlPagar, preferencia.id, RESULTADO_CHECKOUT_RECHAZADO)}">
  <button type="submit" class="rechazar">Rechazar el pago</button>
</form>`);

// Una preferencia que no existe o que ya se resolvió no se puede volver a pagar.
export const renderizarPagoInexistente = (): string =>
  armarPagina('<h1>El pago no existe o ya fue procesado.</h1>');
