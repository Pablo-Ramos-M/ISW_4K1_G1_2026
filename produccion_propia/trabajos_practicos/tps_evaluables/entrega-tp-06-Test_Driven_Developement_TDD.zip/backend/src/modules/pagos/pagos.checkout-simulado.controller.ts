import {
  RESULTADO_CHECKOUT_APROBADO,
  renderizarCheckoutSimulado,
  renderizarPagoInexistente,
} from './pagos.checkout-simulado';
import type { PasarelaPagoSimulada } from './pagos.pasarela-simulada';
import type { RegistroResultadoPago } from './pagos.types';

export interface RespuestaCheckoutHttp {
  estado: number;
  html?: string;
  ubicacion?: string;
}

const PAGO_INEXISTENTE: RespuestaCheckoutHttp = { estado: 404, html: renderizarPagoInexistente() };

export class CheckoutSimuladoController {
  constructor(
    private readonly pasarela: PasarelaPagoSimulada,
    private readonly compras: RegistroResultadoPago,
    private readonly urlPagar: string,
  ) {}

  mostrar(idPreferencia: string): RespuestaCheckoutHttp {
    const preferencia = this.pasarela.buscarPreferencia(idPreferencia);
    if (!preferencia) {
      return PAGO_INEXISTENTE;
    }
    return { estado: 200, html: renderizarCheckoutSimulado(preferencia, this.urlPagar) };
  }

  // Como Mercado Pago: resuelve el pago, avisa al sitio (su webhook) y redirige a la back_url.
  // 303 hace que el navegador vuelva con GET, así recargar la página no reenvía el pago.
  async pagar(idPreferencia: string, resultado: string): Promise<RespuestaCheckoutHttp> {
    const aprobado = resultado === RESULTADO_CHECKOUT_APROBADO;
    const pago = this.pasarela.resolverPago(idPreferencia, aprobado);
    if (!pago) {
      return PAGO_INEXISTENTE;
    }
    await this.compras.registrarResultadoPago(pago.numeroOrden, pago.aprobado);
    return { estado: 303, ubicacion: pago.urlRetorno };
  }
}
