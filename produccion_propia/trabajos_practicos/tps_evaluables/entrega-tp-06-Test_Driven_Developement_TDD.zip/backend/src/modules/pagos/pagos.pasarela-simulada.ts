import type {
  PagoSimulado,
  PasarelaPago,
  PreferenciaPago,
  PreferenciaSimulada,
} from './pagos.types';
import { ESTADO_MP_APROBADO, ESTADO_MP_RECHAZADO, PREFIJO_PREFERENCIA } from './pagos.constants';

const conConsulta = (url: string, parametros: Record<string, string>): string =>
  `${url}?${new URLSearchParams(parametros)}`;

// Imita Checkout Pro: la preferencia queda guardada del lado de la pasarela
// y el comprador es redirigido a un checkout que la muestra (FAQ 4).
export class PasarelaPagoSimulada implements PasarelaPago {
  private readonly preferencias = new Map<string, PreferenciaSimulada>();

  constructor(private readonly config: { urlCheckout: string; urlRetorno: string }) {}

  async crearPreferencia(numeroOrden: string, total: number): Promise<PreferenciaPago> {
    const id = `${PREFIJO_PREFERENCIA}${numeroOrden}`;
    this.preferencias.set(id, { id, numeroOrden, total });
    return { id, urlRedireccion: conConsulta(this.config.urlCheckout, { pref_id: id }) };
  }

  buscarPreferencia(id: string): PreferenciaSimulada | undefined {
    return this.preferencias.get(id);
  }

  // La vuelta al sitio lleva los mismos parámetros que las `back_urls` de Mercado Pago.
  // Cada preferencia se resuelve una sola vez: después ya no se puede volver a pagar.
  resolverPago(idPreferencia: string, aprobado: boolean): PagoSimulado | undefined {
    const preferencia = this.buscarPreferencia(idPreferencia);
    if (!preferencia) return undefined;
    this.preferencias.delete(idPreferencia);
    return {
      numeroOrden: preferencia.numeroOrden,
      aprobado,
      urlRetorno: conConsulta(this.config.urlRetorno, {
        status: aprobado ? ESTADO_MP_APROBADO : ESTADO_MP_RECHAZADO,
        external_reference: preferencia.numeroOrden,
        preference_id: preferencia.id,
      }),
    };
  }
}
