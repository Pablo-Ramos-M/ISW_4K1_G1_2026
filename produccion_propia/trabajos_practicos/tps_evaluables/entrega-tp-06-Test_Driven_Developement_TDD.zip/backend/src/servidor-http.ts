import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import type { CompraController } from './modules/compras/compras.controller';
import type {
  CheckoutSimuladoController,
  RespuestaCheckoutHttp,
} from './modules/pagos/pagos.checkout-simulado.controller';
import { RUTA_CHECKOUT_SIMULADO, RUTA_PAGO_SIMULADO } from './modules/pagos/pagos.constants';

type ControladorCompras = Pick<CompraController, 'comprar' | 'consultar'>;
type ControladorCheckout = Pick<CheckoutSimuladoController, 'mostrar' | 'pagar'>;

const RUTA_COMPRAS = '/api/compras';
const RUTA_COMPRA = /^\/api\/compras\/([^/]+)$/;

const leerCuerpo = async (solicitud: AsyncIterable<Buffer>): Promise<unknown> => {
  const partes: Buffer[] = [];
  for await (const parte of solicitud) partes.push(parte);
  return JSON.parse(Buffer.concat(partes).toString());
};

const responderJson = (respuesta: ServerResponse, estado: number, cuerpo: unknown): void => {
  respuesta.writeHead(estado, { 'content-type': 'application/json' });
  respuesta.end(JSON.stringify(cuerpo));
};

const responderCheckout = (respuesta: ServerResponse, resultado: RespuestaCheckoutHttp): void => {
  if (resultado.ubicacion) {
    respuesta.writeHead(resultado.estado, { location: resultado.ubicacion });
    respuesta.end();
    return;
  }
  respuesta.writeHead(resultado.estado, { 'content-type': 'text/html; charset=utf-8' });
  respuesta.end(resultado.html);
};

const atenderCompra = async (
  controlador: ControladorCompras,
  solicitud: IncomingMessage,
  respuesta: ServerResponse,
): Promise<void> => {
  try {
    const resultado = await controlador.comprar(await leerCuerpo(solicitud));
    responderJson(respuesta, resultado.estado, resultado.cuerpo);
  } catch {
    responderJson(respuesta, 400, { error: 'Solicitud inválida.' });
  }
};

const atenderConsulta = async (
  controlador: ControladorCompras,
  numeroOrden: string,
  respuesta: ServerResponse,
): Promise<void> => {
  const resultado = await controlador.consultar(numeroOrden);
  responderJson(respuesta, resultado.estado, resultado.cuerpo);
};

const rutear = async (
  solicitud: IncomingMessage,
  respuesta: ServerResponse,
  controlador: ControladorCompras,
  checkout?: ControladorCheckout,
): Promise<void> => {
  const { pathname, searchParams } = new URL(solicitud.url ?? '/', 'http://localhost');
  const orden = RUTA_COMPRA.exec(pathname);
  const idPreferencia = searchParams.get('pref_id') ?? '';
  const ruta = `${solicitud.method} ${pathname}`;

  if (checkout && ruta === `GET ${RUTA_CHECKOUT_SIMULADO}`) {
    responderCheckout(respuesta, checkout.mostrar(idPreferencia));
  } else if (checkout && ruta === `POST ${RUTA_PAGO_SIMULADO}`) {
    const resultado = searchParams.get('resultado') ?? '';
    responderCheckout(respuesta, await checkout.pagar(idPreferencia, resultado));
  } else if (ruta === `POST ${RUTA_COMPRAS}`) {
    await atenderCompra(controlador, solicitud, respuesta);
  } else if (solicitud.method === 'GET' && orden) {
    await atenderConsulta(controlador, decodeURIComponent(orden[1]!), respuesta);
  } else {
    responderJson(respuesta, 404, { error: 'No encontrado.' });
  }
};

// El checkout es opcional: solo se monta cuando Mercado Pago está simulado.
export const crearServidor = (
  controlador: ControladorCompras,
  checkout?: ControladorCheckout,
): Server =>
  createServer(async (solicitud, respuesta) => {
    try {
      await rutear(solicitud, respuesta, controlador, checkout);
    } catch (error) {
      // Al cliente no se le muestra el detalle, pero tiene que quedar en el log del servidor.
      console.error('Error inesperado en el servidor HTTP:', error);
      responderJson(respuesta, 500, { error: 'Error interno.' });
    }
  });
