import { afterEach, describe, expect, it } from 'vitest';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { ConexionSqlite } from '../../../src/infraestructura/bd/conexion-sqlite';

describe('ConexionSqlite', () => {
  let conexion: ConexionSqlite | undefined;

  afterEach(() => conexion?.cerrar());

  it('crea únicamente las tablas del modelo de compras', () => {
    conexion = new ConexionSqlite(':memory:');

    const tablas = conexion.baseDatos
      .prepare("SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name")
      .all()
      .map((fila) => (fila as { name: string }).name);

    expect(tablas).toEqual(['compras', 'entradas', 'usuarios']);
  });

  it('activa las claves foráneas', () => {
    conexion = new ConexionSqlite(':memory:');

    expect(() =>
      conexion?.baseDatos
        .prepare(
          `INSERT INTO compras
             (numero_orden, email, fecha_visita, forma_pago, total)
           VALUES (?, ?, ?, ?, ?)`,
        )
        .run('ORD-1', 'inexistente@mail.com', '2026-10-20', 'EFECTIVO', 1000),
    ).toThrow();
  });

  it('agrega el estado del pago a una base creada antes de que existiera', () => {
    const carpeta = mkdtempSync(join(tmpdir(), 'parque-'));
    const ruta = join(carpeta, 'parque.sqlite');
    const anterior = new DatabaseSync(ruta);
    anterior.exec(`
      CREATE TABLE compras (numero_orden TEXT PRIMARY KEY, email TEXT NOT NULL,
        fecha_visita TEXT NOT NULL, forma_pago TEXT NOT NULL, total INTEGER NOT NULL);
      INSERT INTO compras VALUES ('ORD-1', 'visitante@mail.com', '2026-10-20', 'EFECTIVO', 1000);
    `);
    anterior.close();

    try {
      conexion = new ConexionSqlite(ruta);

      expect(conexion.baseDatos.prepare('SELECT estado_pago FROM compras').all()).toEqual([
        { estado_pago: 'PENDIENTE' },
      ]);
    } finally {
      conexion?.cerrar();
      conexion = undefined;
      rmSync(carpeta, { recursive: true, force: true });
    }
  });
});
