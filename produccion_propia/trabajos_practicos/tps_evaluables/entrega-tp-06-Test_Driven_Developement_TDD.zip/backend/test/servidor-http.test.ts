import { afterEach, describe, expect, it, vi } from 'vitest';
import type { Server } from 'node:http';
import type { CompraController } from '../src/modules/compras/compras.controller';
import type { CheckoutSimuladoController } from '../src/modules/pagos/pagos.checkout-simulado.controller';
import { crearServidor } from '../src/servidor-http';

const crearCompras = () => ({
  comprar: vi.fn<CompraController['comprar']>(),
  consultar: vi
    .fn<CompraController['consultar']>()
    .mockResolvedValue({ estado: 200, cuerpo: { numeroOrden: 'ORD-1' } }),
});

const crearCheckout = () => ({
  mostrar: vi
    .fn<CheckoutSimuladoController['mostrar']>()
    .mockReturnValue({ estado: 200, html: '<h1>Checkout</h1>' }),
  pagar: vi.fn<CheckoutSimuladoController['pagar']>(),
});

const iniciar = async (
  compras: ReturnType<typeof crearCompras>,
  checkout: ReturnType<typeof crearCheckout> = crearCheckout(),
) => {
  const servidor = crearServidor(compras, checkout);
  await new Promise<void>((resolve) => servidor.listen(0, '127.0.0.1', resolve));
  const direccion = servidor.address();
  if (!direccion || typeof direccion === 'string') throw new Error('No se pudo obtener el puerto.');
  return { servidor, base: `http://127.0.0.1:${direccion.port}` };
};

describe('servidor HTTP', () => {
  let servidor: Server | undefined;

  afterEach(async () => {
    if (servidor?.listening)
      await new Promise<void>((resolve, reject) =>
        servidor?.close((error) => (error ? reject(error) : resolve())),
      );
  });

  it('GET /api/compras/:orden consulta la compra', async () => {
    const compras = crearCompras();
    const sistema = await iniciar(compras);
    servidor = sistema.servidor;

    const respuesta = await fetch(`${sistema.base}/api/compras/ORD-1`);

    expect(respuesta.status).toBe(200);
    await expect(respuesta.json()).resolves.toEqual({ numeroOrden: 'ORD-1' });
    expect(compras.consultar).toHaveBeenCalledWith('ORD-1');
  });

  it('GET /api/mp-simulado/checkout muestra la página del checkout simulado', async () => {
    const checkout = crearCheckout();
    const sistema = await iniciar(crearCompras(), checkout);
    servidor = sistema.servidor;

    const respuesta = await fetch(`${sistema.base}/api/mp-simulado/checkout?pref_id=PREF-ORD-1`);

    expect(respuesta.status).toBe(200);
    expect(respuesta.headers.get('content-type')).toBe('text/html; charset=utf-8');
    await expect(respuesta.text()).resolves.toBe('<h1>Checkout</h1>');
    expect(checkout.mostrar).toHaveBeenCalledWith('PREF-ORD-1');
  });

  it('POST /api/mp-simulado/pagar resuelve el pago y redirige a la back_url', async () => {
    const checkout = crearCheckout();
    checkout.pagar.mockResolvedValue({ estado: 303, ubicacion: '/?status=approved' });
    const sistema = await iniciar(crearCompras(), checkout);
    servidor = sistema.servidor;

    const respuesta = await fetch(
      `${sistema.base}/api/mp-simulado/pagar?pref_id=PREF-ORD-1&resultado=aprobado`,
      { method: 'POST', redirect: 'manual' },
    );

    expect(respuesta.status).toBe(303);
    expect(respuesta.headers.get('location')).toBe('/?status=approved');
    expect(checkout.pagar).toHaveBeenCalledWith('PREF-ORD-1', 'aprobado');
  });

  it('responde 500 y lo registra si falla algo inesperado', async () => {
    const error = new Error('fallo de infraestructura');
    const consola = vi.spyOn(console, 'error').mockImplementation(() => {});
    const checkout = crearCheckout();
    checkout.pagar.mockRejectedValue(error);
    const sistema = await iniciar(crearCompras(), checkout);
    servidor = sistema.servidor;

    const respuesta = await fetch(
      `${sistema.base}/api/mp-simulado/pagar?pref_id=PREF-ORD-1&resultado=aprobado`,
      { method: 'POST', redirect: 'manual', signal: AbortSignal.timeout(2000) },
    );

    expect(respuesta.status).toBe(500);
    expect(consola).toHaveBeenCalledWith(expect.any(String), error);
    consola.mockRestore();
  });
});
