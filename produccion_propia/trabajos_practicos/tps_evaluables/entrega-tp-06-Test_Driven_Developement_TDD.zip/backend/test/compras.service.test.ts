import { describe, it, expect, vi } from 'vitest';
import { ComprasService } from '../src/modules/compras/compras.service';
import type {
  CompraRegistrada,
  EstadoPagoCompra,
  NuevaCompra,
  ResumenCompra,
  SolicitudCompra,
} from '../src/modules/compras/compras.types';
import type { DetallePrecio, ResultadoPago, Visitante } from '../src/modules/pagos/pagos.types';

// Tests unitarios: parque, pagos, repositorios y mail son fakes,
// así ComprasService se puede desarrollar sin esperar a los otros módulos.

const EMAIL = 'visitante@mail.com';
const FECHA_VISITA = new Date(2026, 9, 15); // jueves 15/10/2026
const URL_MP = 'https://sandbox.mercadopago.com.ar/checkout?pref_id=pref-123';

const DETALLE: DetallePrecio = {
  subtotales: [
    { edad: 35, tipoPase: 'VIP', precio: 20000 },
    { edad: 10, tipoPase: 'REGULAR', precio: 5000 },
  ],
  total: 25000,
};

const PAGO_TARJETA: ResultadoPago = {
  formaPago: 'TARJETA',
  estado: 'REDIRIGIDO_A_MERCADO_PAGO',
  urlRedireccion: URL_MP,
};

const PAGO_EFECTIVO: ResultadoPago = { formaPago: 'EFECTIVO', estado: 'PENDIENTE_EN_BOLETERIA' };

const visitantes = (cantidad: number): Visitante[] =>
  Array.from({ length: cantidad }, () => ({ edad: 30, tipoPase: 'REGULAR' }));

const solicitudValida = (cambios: Partial<SolicitudCompra> = {}): SolicitudCompra => ({
  email: EMAIL,
  fechaVisita: FECHA_VISITA,
  cantidad: 2,
  visitantes: [
    { edad: 35, tipoPase: 'VIP' },
    { edad: 10, tipoPase: 'REGULAR' },
  ],
  formaPago: 'TARJETA',
  ...cambios,
});

const COMPRA_CON_TARJETA: CompraRegistrada = {
  numeroOrden: 'ORD-0001',
  email: EMAIL,
  fechaVisita: FECHA_VISITA,
  formaPago: 'TARJETA',
  estadoPago: 'PENDIENTE',
  detalle: DETALLE,
};

const SOLICITUD_EFECTIVO = solicitudValida({ formaPago: 'EFECTIVO' });

const crearDependencias = () => ({
  parque: { validarFechaVisita: vi.fn<(fechaVisita: Date, ahora?: Date) => void>() },
  pagos: {
    calcularDetalle: vi.fn<(visitantes: Visitante[]) => DetallePrecio>().mockReturnValue(DETALLE),
    procesarPago: vi.fn<() => Promise<ResultadoPago>>().mockResolvedValue(PAGO_TARJETA),
  },
  compras: {
    contarEntradas: vi.fn<(email: string, fecha: Date) => Promise<number>>().mockResolvedValue(0),
    guardar: vi.fn<(compra: NuevaCompra) => Promise<string>>().mockResolvedValue('ORD-0001'),
    buscar: vi
      .fn<(numeroOrden: string) => Promise<CompraRegistrada | undefined>>()
      .mockResolvedValue(COMPRA_CON_TARJETA),
    actualizarEstadoPago: vi
      .fn<(numeroOrden: string, estado: EstadoPagoCompra) => Promise<void>>()
      .mockResolvedValue(undefined),
  },
  notificador: {
    enviarConfirmacion: vi
      .fn<(email: string, resumen: ResumenCompra) => Promise<void>>()
      .mockResolvedValue(undefined),
  },
  usuarios: {
    estaRegistrado: vi.fn<(email: string) => Promise<boolean>>().mockResolvedValue(true),
  },
});

describe('ComprasService.comprarEntradas', () => {
  describe('compra exitosa', () => {
    it('informa número de orden, cantidad de entradas, fecha de visita y total', async () => {
      const servicio = new ComprasService(crearDependencias());

      const resultado = await servicio.comprarEntradas(solicitudValida());

      expect(resultado).toMatchObject({
        numeroOrden: 'ORD-0001',
        cantidadEntradas: 2,
        fechaVisita: FECHA_VISITA,
        total: 25000,
      });
    });

    it('con tarjeta devuelve la redirección a Mercado Pago', async () => {
      const deps = crearDependencias();
      const servicio = new ComprasService(deps);

      const resultado = await servicio.comprarEntradas(solicitudValida({ formaPago: 'TARJETA' }));

      expect(deps.pagos.procesarPago).toHaveBeenCalledWith('ORD-0001', 25000, 'TARJETA');
      expect(resultado.pago).toEqual(PAGO_TARJETA);
    });

    it('con efectivo deja el pago pendiente en boletería', async () => {
      const deps = crearDependencias();
      deps.pagos.procesarPago.mockResolvedValue(PAGO_EFECTIVO);
      const servicio = new ComprasService(deps);

      const resultado = await servicio.comprarEntradas(solicitudValida({ formaPago: 'EFECTIVO' }));

      expect(deps.pagos.procesarPago).toHaveBeenCalledWith('ORD-0001', 25000, 'EFECTIVO');
      expect(resultado.pago).toEqual(PAGO_EFECTIVO);
    });

    it('registra la compra con sus visitantes, forma de pago y detalle de precios', async () => {
      const deps = crearDependencias();
      const servicio = new ComprasService(deps);
      const solicitud = solicitudValida();

      await servicio.comprarEntradas(solicitud);

      expect(deps.pagos.calcularDetalle).toHaveBeenCalledWith(solicitud.visitantes);
      expect(deps.compras.guardar).toHaveBeenCalledWith({
        email: EMAIL,
        fechaVisita: FECHA_VISITA,
        visitantes: solicitud.visitantes,
        formaPago: 'TARJETA',
        detalle: DETALLE,
      });
    });

    it('con efectivo envía el mail de confirmación con el resumen de la compra', async () => {
      const deps = crearDependencias();
      const servicio = new ComprasService(deps);

      await servicio.comprarEntradas(SOLICITUD_EFECTIVO);

      expect(deps.notificador.enviarConfirmacion).toHaveBeenCalledWith(
        EMAIL,
        expect.objectContaining({
          numeroOrden: 'ORD-0001',
          fechaVisita: FECHA_VISITA,
          cantidadEntradas: 2,
          formaPago: 'EFECTIVO',
          detalle: DETALLE,
        }),
      );
    });

    it('con tarjeta no envía el mail hasta que Mercado Pago apruebe el pago', async () => {
      const deps = crearDependencias();
      const servicio = new ComprasService(deps);

      await servicio.comprarEntradas(solicitudValida({ formaPago: 'TARJETA' }));

      expect(deps.notificador.enviarConfirmacion).not.toHaveBeenCalled();
    });

    it('el mail de confirmación incluye un código QR por entrada', async () => {
      const deps = crearDependencias();
      const servicio = new ComprasService(deps);

      await servicio.comprarEntradas(SOLICITUD_EFECTIVO);

      expect(deps.notificador.enviarConfirmacion).toHaveBeenCalledOnce();
      const [, resumen] = deps.notificador.enviarConfirmacion.mock.calls[0]!;
      expect(resumen.entradas).toEqual([
        { edad: 35, tipoPase: 'VIP', precio: 20000, codigoQR: expect.any(String) },
        { edad: 10, tipoPase: 'REGULAR', precio: 5000, codigoQR: expect.any(String) },
      ]);
    });

    it('cada entrada tiene un código QR distinto que referencia la orden', async () => {
      const deps = crearDependencias();
      const servicio = new ComprasService(deps);

      await servicio.comprarEntradas(SOLICITUD_EFECTIVO);

      const [, resumen] = deps.notificador.enviarConfirmacion.mock.calls[0]!;
      const codigos = resumen.entradas.map((entrada) => entrada.codigoQR);
      expect(new Set(codigos).size).toBe(codigos.length);
      for (const codigo of codigos) expect(codigo).toContain('ORD-0001');
    });

    it('valida la fecha de visita contra las reglas del parque', async () => {
      const deps = crearDependencias();
      const servicio = new ComprasService(deps);

      await servicio.comprarEntradas(solicitudValida());

      expect(deps.parque.validarFechaVisita).toHaveBeenCalledWith(FECHA_VISITA);
    });

    it('permite comprar 10 entradas en una sola transacción', async () => {
      const servicio = new ComprasService(crearDependencias());

      await expect(
        servicio.comprarEntradas(solicitudValida({ cantidad: 10, visitantes: visitantes(10) })),
      ).resolves.toMatchObject({ cantidadEntradas: 10 });
    });

    it('permite completar 10 entradas para una fecha sumando compras anteriores', async () => {
      const deps = crearDependencias();
      deps.compras.contarEntradas.mockResolvedValue(8);
      const servicio = new ComprasService(deps);

      await expect(servicio.comprarEntradas(solicitudValida())).resolves.toMatchObject({
        cantidadEntradas: 2,
      });
    });
  });

  describe('validaciones', () => {
    it('rechaza la compra de un usuario no registrado', async () => {
      const deps = crearDependencias();
      deps.usuarios.estaRegistrado.mockResolvedValue(false);
      const servicio = new ComprasService(deps);

      await expect(servicio.comprarEntradas(solicitudValida())).rejects.toThrow(
        'Solo los usuarios registrados pueden comprar entradas.',
      );
      expect(deps.compras.guardar).not.toHaveBeenCalled();
    });

    it('rechaza la compra sin forma de pago seleccionada', async () => {
      const deps = crearDependencias();
      const servicio = new ComprasService(deps);

      await expect(
        servicio.comprarEntradas(solicitudValida({ formaPago: undefined })),
      ).rejects.toThrow('Debe seleccionar una forma de pago.');
      expect(deps.compras.guardar).not.toHaveBeenCalled();
      expect(deps.pagos.procesarPago).not.toHaveBeenCalled();
    });

    it('rechaza la compra si el parque está cerrado en la fecha elegida', async () => {
      const deps = crearDependencias();
      const fechaLunes = new Date(2026, 9, 26); // lunes 26/10/2026
      const servicio = new ComprasService(deps);

      deps.parque.validarFechaVisita.mockImplementation((fecha) => {
        if (fecha.getDay() === 1) {
          throw new Error('El parque está cerrado en la fecha seleccionada.');
        }
      });

      await expect(
        servicio.comprarEntradas(solicitudValida({ fechaVisita: fechaLunes })),
      ).rejects.toThrow('El parque está cerrado en la fecha seleccionada.');
      expect(deps.compras.guardar).not.toHaveBeenCalled();
    });

    it('rechaza la compra de más de 10 entradas', async () => {
      const deps = crearDependencias();
      const servicio = new ComprasService(deps);

      await expect(
        servicio.comprarEntradas(solicitudValida({ cantidad: 11, visitantes: visitantes(11) })),
      ).rejects.toThrow('No se pueden comprar más de 10 entradas.');
      expect(deps.compras.guardar).not.toHaveBeenCalled();
    });

    it('rechaza la compra de 0 entradas', async () => {
      const deps = crearDependencias();
      const servicio = new ComprasService(deps);

      await expect(
        servicio.comprarEntradas(solicitudValida({ cantidad: 0, visitantes: [] })),
      ).rejects.toThrow('Debe comprar al menos una entrada.');
      expect(deps.compras.guardar).not.toHaveBeenCalled();
    });

    it('rechaza la compra si con compras anteriores se superan 10 entradas para esa fecha', async () => {
      const deps = crearDependencias();
      deps.compras.contarEntradas.mockResolvedValue(9);
      const servicio = new ComprasService(deps);

      await expect(servicio.comprarEntradas(solicitudValida())).rejects.toThrow(
        'Supera el máximo de 10 entradas para la fecha seleccionada.',
      );
      expect(deps.compras.contarEntradas).toHaveBeenCalledWith(EMAIL, FECHA_VISITA);
      expect(deps.compras.guardar).not.toHaveBeenCalled();
    });

    it('rechaza la compra si no se indican edad y pase de cada visitante', async () => {
      const deps = crearDependencias();
      const servicio = new ComprasService(deps);

      await expect(
        servicio.comprarEntradas(solicitudValida({ cantidad: 3, visitantes: visitantes(2) })),
      ).rejects.toThrow('Debe indicar la edad y el tipo de pase de cada visitante.');
      expect(deps.compras.guardar).not.toHaveBeenCalled();
    });

    it('no envía el mail de confirmación si el pago no se pudo iniciar', async () => {
      const deps = crearDependencias();
      deps.pagos.procesarPago.mockRejectedValue(
        new Error('No se pudo iniciar el pago con Mercado Pago.'),
      );
      const servicio = new ComprasService(deps);

      await expect(servicio.comprarEntradas(solicitudValida())).rejects.toThrow(
        'No se pudo iniciar el pago con Mercado Pago.',
      );
      expect(deps.notificador.enviarConfirmacion).not.toHaveBeenCalled();
    });
  });
});

describe('ComprasService.registrarResultadoPago', () => {
  it('con el pago aprobado marca la orden y envía el mail con un QR por entrada', async () => {
    const deps = crearDependencias();
    const servicio = new ComprasService(deps);

    await servicio.registrarResultadoPago('ORD-0001', true);

    expect(deps.compras.actualizarEstadoPago).toHaveBeenCalledWith('ORD-0001', 'APROBADO');
    expect(deps.notificador.enviarConfirmacion).toHaveBeenCalledWith(EMAIL, {
      numeroOrden: 'ORD-0001',
      fechaVisita: FECHA_VISITA,
      cantidadEntradas: 2,
      formaPago: 'TARJETA',
      detalle: DETALLE,
      entradas: [
        { edad: 35, tipoPase: 'VIP', precio: 20000, codigoQR: 'QR-ORD-0001-1' },
        { edad: 10, tipoPase: 'REGULAR', precio: 5000, codigoQR: 'QR-ORD-0001-2' },
      ],
    });
  });

  it('con el pago rechazado marca la orden y no envía el mail', async () => {
    const deps = crearDependencias();
    const servicio = new ComprasService(deps);

    await servicio.registrarResultadoPago('ORD-0001', false);

    expect(deps.compras.actualizarEstadoPago).toHaveBeenCalledWith('ORD-0001', 'RECHAZADO');
    expect(deps.notificador.enviarConfirmacion).not.toHaveBeenCalled();
  });

  it('rechaza el resultado de pago de una orden inexistente', async () => {
    const deps = crearDependencias();
    deps.compras.buscar.mockResolvedValue(undefined);
    const servicio = new ComprasService(deps);

    await expect(servicio.registrarResultadoPago('ORD-NO-EXISTE', true)).rejects.toThrow(
      'La orden no existe.',
    );
    expect(deps.compras.actualizarEstadoPago).not.toHaveBeenCalled();
  });

  it('ignora un resultado repetido de un pago ya resuelto', async () => {
    const deps = crearDependencias();
    deps.compras.buscar.mockResolvedValue({ ...COMPRA_CON_TARJETA, estadoPago: 'APROBADO' });
    const servicio = new ComprasService(deps);

    await servicio.registrarResultadoPago('ORD-0001', true);

    expect(deps.compras.actualizarEstadoPago).not.toHaveBeenCalled();
    expect(deps.notificador.enviarConfirmacion).not.toHaveBeenCalled();
  });
});

describe('ComprasService.consultarCompra', () => {
  it('informa los datos de la orden y el estado del pago', async () => {
    const servicio = new ComprasService(crearDependencias());

    await expect(servicio.consultarCompra('ORD-0001')).resolves.toEqual({
      numeroOrden: 'ORD-0001',
      cantidadEntradas: 2,
      fechaVisita: FECHA_VISITA,
      total: 25000,
      formaPago: 'TARJETA',
      estadoPago: 'PENDIENTE',
    });
  });
});
