import { describe, expect, it, vi } from 'vitest';
import { CheckoutSimuladoController } from '../../../src/modules/pagos/pagos.checkout-simulado.controller';
import { PasarelaPagoSimulada } from '../../../src/modules/pagos/pagos.pasarela-simulada';

const crearSistema = async () => {
  const pasarela = new PasarelaPagoSimulada({
    urlCheckout: '/api/mp-simulado/checkout',
    urlRetorno: '/',
  });
  await pasarela.crearPreferencia('ORD-123', 25000);
  const compras = {
    registrarResultadoPago: vi
      .fn<(numeroOrden: string, aprobado: boolean) => Promise<void>>()
      .mockResolvedValue(undefined),
  };
  const controlador = new CheckoutSimuladoController(pasarela, compras, '/api/mp-simulado/pagar');
  return { controlador, compras };
};

describe('CheckoutSimuladoController', () => {
  it('muestra el checkout de una preferencia existente', async () => {
    const { controlador } = await crearSistema();

    const respuesta = controlador.mostrar('PREF-ORD-123');

    expect(respuesta.estado).toBe(200);
    expect(respuesta.html).toContain('ORD-123');
  });

  it('responde 404 si la preferencia no existe o ya se pagó', async () => {
    const { controlador } = await crearSistema();

    const respuesta = controlador.mostrar('PREF-NO-EXISTE');

    expect(respuesta.estado).toBe(404);
    expect(respuesta.html).toContain('El pago no existe o ya fue procesado.');
  });

  it('al pagar registra el pago aprobado y vuelve al sitio', async () => {
    const { controlador, compras } = await crearSistema();

    const respuesta = await controlador.pagar('PREF-ORD-123', 'aprobado');

    expect(compras.registrarResultadoPago).toHaveBeenCalledWith('ORD-123', true);
    expect(respuesta).toEqual({
      estado: 303,
      ubicacion: '/?status=approved&external_reference=ORD-123&preference_id=PREF-ORD-123',
    });
  });

  it('al rechazar registra el pago rechazado y vuelve al sitio', async () => {
    const { controlador, compras } = await crearSistema();

    const respuesta = await controlador.pagar('PREF-ORD-123', 'rechazado');

    expect(compras.registrarResultadoPago).toHaveBeenCalledWith('ORD-123', false);
    expect(respuesta.ubicacion).toContain('status=rejected');
  });

  it('no paga dos veces la misma preferencia', async () => {
    const { controlador, compras } = await crearSistema();
    await controlador.pagar('PREF-ORD-123', 'aprobado');

    const respuesta = await controlador.pagar('PREF-ORD-123', 'aprobado');

    expect(respuesta.estado).toBe(404);
    expect(compras.registrarResultadoPago).toHaveBeenCalledOnce();
  });
});
