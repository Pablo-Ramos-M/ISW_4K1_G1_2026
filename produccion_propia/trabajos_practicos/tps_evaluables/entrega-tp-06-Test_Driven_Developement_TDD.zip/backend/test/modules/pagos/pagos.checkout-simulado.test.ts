import { describe, expect, it } from 'vitest';
import { renderizarCheckoutSimulado } from '../../../src/modules/pagos/pagos.checkout-simulado';

const PREFERENCIA = { id: 'PREF-ORD-123', numeroOrden: 'ORD-123', total: 25000 };
const URL_PAGAR = '/api/mp-simulado/pagar';

describe('renderizarCheckoutSimulado', () => {
  it('muestra el importe a pagar y la orden', () => {
    const html = renderizarCheckoutSimulado(PREFERENCIA, URL_PAGAR);

    expect(html).toContain('$\u00a025.000');
    expect(html).toContain('ORD-123');
  });

  it('ofrece pagar o rechazar el pago de la preferencia', () => {
    const html = renderizarCheckoutSimulado(PREFERENCIA, URL_PAGAR);

    expect(html).toContain(
      '<form method="post" action="/api/mp-simulado/pagar?pref_id=PREF-ORD-123&amp;resultado=aprobado">',
    );
    expect(html).toContain(
      '<form method="post" action="/api/mp-simulado/pagar?pref_id=PREF-ORD-123&amp;resultado=rechazado">',
    );
  });
});
