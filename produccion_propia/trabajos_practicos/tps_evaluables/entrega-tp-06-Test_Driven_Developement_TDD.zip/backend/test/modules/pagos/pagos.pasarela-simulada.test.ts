import { describe, expect, it } from 'vitest';
import { PasarelaPagoSimulada } from '../../../src/modules/pagos/pagos.pasarela-simulada';

const URL_CHECKOUT = '/api/mp-simulado/checkout';
const URL_RETORNO = '/';

const crearPasarela = () =>
  new PasarelaPagoSimulada({ urlCheckout: URL_CHECKOUT, urlRetorno: URL_RETORNO });

const crearPasarelaConPreferencia = async () => {
  const pasarela = crearPasarela();
  await pasarela.crearPreferencia('ORD-123', 25000);
  return pasarela;
};

describe('PasarelaPagoSimulada', () => {
  it('redirige al checkout simulado con el id de la preferencia', async () => {
    const pasarela = crearPasarela();

    await expect(pasarela.crearPreferencia('ORD-123', 25000)).resolves.toEqual({
      id: 'PREF-ORD-123',
      urlRedireccion: '/api/mp-simulado/checkout?pref_id=PREF-ORD-123',
    });
  });

  it('guarda la preferencia con la orden y el total para mostrarla en el checkout', async () => {
    const pasarela = await crearPasarelaConPreferencia();

    expect(pasarela.buscarPreferencia('PREF-ORD-123')).toEqual({
      id: 'PREF-ORD-123',
      numeroOrden: 'ORD-123',
      total: 25000,
    });
  });

  it('al aprobar el pago vuelve al sitio con los parámetros de Mercado Pago', async () => {
    const pasarela = await crearPasarelaConPreferencia();

    expect(pasarela.resolverPago('PREF-ORD-123', true)).toEqual({
      numeroOrden: 'ORD-123',
      aprobado: true,
      urlRetorno: '/?status=approved&external_reference=ORD-123&preference_id=PREF-ORD-123',
    });
  });

  it('al rechazar el pago vuelve al sitio con el estado rechazado', async () => {
    const pasarela = await crearPasarelaConPreferencia();

    expect(pasarela.resolverPago('PREF-ORD-123', false)).toEqual({
      numeroOrden: 'ORD-123',
      aprobado: false,
      urlRetorno: '/?status=rejected&external_reference=ORD-123&preference_id=PREF-ORD-123',
    });
  });

  it('no resuelve el pago de una preferencia inexistente', () => {
    expect(crearPasarela().resolverPago('PREF-NO-EXISTE', true)).toBeUndefined();
  });

  it('una preferencia ya resuelta no se puede volver a pagar', async () => {
    const pasarela = await crearPasarelaConPreferencia();
    pasarela.resolverPago('PREF-ORD-123', false);

    expect(pasarela.resolverPago('PREF-ORD-123', true)).toBeUndefined();
    expect(pasarela.buscarPreferencia('PREF-ORD-123')).toBeUndefined();
  });
});
