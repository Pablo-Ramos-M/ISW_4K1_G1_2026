import { afterEach, describe, expect, it, vi } from 'vitest';
import type { Server } from 'node:http';
import type { ComprasService } from '../../../src/modules/compras/compras.service';
import type {
  ConsultaCompra,
  ResultadoCompra,
  SolicitudCompra,
} from '../../../src/modules/compras/compras.types';
import { crearServidor } from '../../../src/servidor-http';
import { CompraController } from '../../../src/modules/compras/compras.controller';

const CONSULTA: ConsultaCompra = {
  numeroOrden: 'ORD-1',
  cantidadEntradas: 2,
  fechaVisita: new Date(2026, 9, 20), // martes 20/10/2026
  total: 25000,
  formaPago: 'TARJETA',
  estadoPago: 'APROBADO',
};

class ComprasServiceFalso implements Pick<ComprasService, 'comprarEntradas' | 'consultarCompra'> {
  solicitudes: SolicitudCompra[] = [];

  constructor(
    private readonly resultado: ResultadoCompra | Error,
    private readonly consulta: ConsultaCompra | Error = CONSULTA,
  ) {}

  async consultarCompra(_numeroOrden: string): Promise<ConsultaCompra> {
    if (this.consulta instanceof Error) {
      throw this.consulta;
    }
    return this.consulta;
  }

  async comprarEntradas(solicitud: SolicitudCompra): Promise<ResultadoCompra> {
    this.solicitudes.push(solicitud);
    if (this.resultado instanceof Error) {
      throw this.resultado;
    }
    return this.resultado;
  }
}

const RESULTADO: ResultadoCompra = {
  numeroOrden: 'ORD-1',
  cantidadEntradas: 1,
  fechaVisita: new Date(2026, 9, 20), // martes 20/10/2026
  total: 10000,
  pago: { formaPago: 'EFECTIVO', estado: 'PENDIENTE_EN_BOLETERIA' },
};

const CUERPO_VALIDO = {
  email: 'visitante@mail.com',
  fechaVisita: '2026-10-20',
  cantidad: 1,
  visitantes: [{ edad: 30, tipoPase: 'REGULAR' }],
  formaPago: 'EFECTIVO',
};

const iniciar = async (
  servicio: ComprasServiceFalso,
): Promise<{ servidor: Server; url: string }> => {
  const servidor = crearServidor(new CompraController(servicio));
  await new Promise<void>((resolve) => servidor.listen(0, '127.0.0.1', resolve));
  const direccion = servidor.address();
  if (!direccion || typeof direccion === 'string') throw new Error('No se pudo obtener el puerto.');
  return { servidor, url: `http://127.0.0.1:${direccion.port}/api/compras` };
};

describe('CompraController', () => {
  let servidor: Server | undefined;

  afterEach(async () => {
    vi.restoreAllMocks();
    if (servidor?.listening)
      await new Promise<void>((resolve, reject) =>
        servidor?.close((error) => (error ? reject(error) : resolve())),
      );
  });

  it('confirma una solicitud válida con 201', async () => {
    const servicio = new ComprasServiceFalso(RESULTADO);
    const sistema = await iniciar(servicio);
    servidor = sistema.servidor;

    const respuesta = await fetch(sistema.url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(CUERPO_VALIDO),
    });

    expect(respuesta.status).toBe(201);
    expect(await respuesta.json()).toMatchObject({ numeroOrden: 'ORD-1' });
    expect(servicio.solicitudes).toEqual([
      { ...CUERPO_VALIDO, fechaVisita: new Date(2026, 9, 20) }, // martes 20/10/2026
    ]);
  });

  it('rechaza JSON inválido con 400', async () => {
    const sistema = await iniciar(new ComprasServiceFalso(RESULTADO));
    servidor = sistema.servidor;

    const respuesta = await fetch(sistema.url, { method: 'POST', body: '{' });

    expect(respuesta.status).toBe(400);
  });

  it('traduce errores de regla a 422', async () => {
    const sistema = await iniciar(
      new ComprasServiceFalso(new Error('El parque está cerrado en la fecha seleccionada.')),
    );
    servidor = sistema.servidor;

    const respuesta = await fetch(sistema.url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(CUERPO_VALIDO),
    });

    expect(respuesta.status).toBe(422);
  });

  it('oculta errores inesperados con 500 y los registra en la consola', async () => {
    const error = new Error('fallo de infraestructura');
    const consola = vi.spyOn(console, 'error').mockImplementation(() => {});
    const sistema = await iniciar(new ComprasServiceFalso(error));
    servidor = sistema.servidor;

    const respuesta = await fetch(sistema.url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(CUERPO_VALIDO),
    });

    expect(respuesta.status).toBe(500);
    await expect(respuesta.json()).resolves.toEqual({ error: 'Error interno.' });
    expect(consola).toHaveBeenCalledWith(expect.any(String), error);
  });
});

describe('CompraController.consultar', () => {
  it('devuelve la compra con la fecha de visita como AAAA-MM-DD', async () => {
    const controlador = new CompraController(new ComprasServiceFalso(RESULTADO));

    await expect(controlador.consultar('ORD-1')).resolves.toEqual({
      estado: 200,
      cuerpo: { ...CONSULTA, fechaVisita: '2026-10-20' },
    });
  });

  it('responde 404 si la orden no existe', async () => {
    const controlador = new CompraController(
      new ComprasServiceFalso(RESULTADO, new Error('La orden no existe.')),
    );

    await expect(controlador.consultar('ORD-NO-EXISTE')).resolves.toEqual({
      estado: 404,
      cuerpo: { error: 'La orden no existe.' },
    });
  });

  it('oculta errores inesperados con 500 y los registra en la consola', async () => {
    const error = new Error('fallo de infraestructura');
    const consola = vi.spyOn(console, 'error').mockImplementation(() => {});
    const controlador = new CompraController(new ComprasServiceFalso(RESULTADO, error));

    await expect(controlador.consultar('ORD-1')).resolves.toEqual({
      estado: 500,
      cuerpo: { error: 'Error interno.' },
    });
    expect(consola).toHaveBeenCalledWith(expect.any(String), error);
    consola.mockRestore();
  });
});
