import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { Server } from 'node:http';
import { crearAplicacion } from '../../../src/aplicacion';
import { NotificadorMail } from '../../../src/modules/compras/compras.notificador-mail';
import type { DependenciasCompras } from '../../../src/modules/compras/compras.types';
import { CheckoutSimuladoController } from '../../../src/modules/pagos/pagos.checkout-simulado.controller';
import {
  RUTA_CHECKOUT_SIMULADO,
  RUTA_PAGO_SIMULADO,
} from '../../../src/modules/pagos/pagos.constants';
import { PasarelaPagoSimulada } from '../../../src/modules/pagos/pagos.pasarela-simulada';
import { crearServidor } from '../../../src/servidor-http';
import { NotificadorFalso } from '../../fakes/notificador.falso';
import { PasarelaPagoFalsa } from '../../fakes/pasarela-pago.falsa';
import { TransporteMailFalso } from '../../fakes/transporte-mail.falso';
import { leerQR } from '../../helpers/leer-qr';

const SOLICITUD_VALIDA = {
  email: 'visitante@mail.com',
  fechaVisita: '2026-10-20',
  cantidad: 2,
  visitantes: [
    { edad: 35, tipoPase: 'VIP' },
    { edad: 10, tipoPase: 'REGULAR' },
  ],
  formaPago: 'TARJETA',
};

const crearSistemaDePrueba = async (notificador: DependenciasCompras['notificador']) => {
  const pasarela = new PasarelaPagoFalsa({
    id: 'PREF-PRUEBA',
    urlRedireccion: 'https://pago.simulado/checkout',
  });
  const aplicacion = crearAplicacion({ ruta: ':memory:', pasarela, notificador });
  aplicacion.conexion.baseDatos
    .prepare('INSERT INTO usuarios(email) VALUES (?)')
    .run('visitante@mail.com');
  const servidor = crearServidor(aplicacion.controlador);
  await new Promise<void>((resolve) => servidor.listen(0, '127.0.0.1', resolve));
  const direccion = servidor.address();
  if (!direccion || typeof direccion === 'string') throw new Error('No se pudo obtener el puerto.');
  return {
    aplicacion,
    servidor,
    pasarela,
    url: `http://127.0.0.1:${direccion.port}/api/compras`,
  };
};

describe('POST /api/compras integrado', () => {
  let servidor: Server | undefined;
  let cerrarBaseDatos: (() => void) | undefined;

  beforeEach(() => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(new Date(2026, 9, 20, 10, 0)); // martes 20/10/2026, 10:00
  });

  afterEach(async () => {
    vi.useRealTimers();
    if (servidor?.listening) {
      await new Promise<void>((resolve, reject) =>
        servidor?.close((error) => (error ? reject(error) : resolve())),
      );
    }
    cerrarBaseDatos?.();
  });

  it('persiste la compra y devuelve el pago con tarjeta simulado', async () => {
    const notificador = new NotificadorFalso();
    const sistema = await crearSistemaDePrueba(notificador);
    const { aplicacion, pasarela } = sistema;
    cerrarBaseDatos = () => aplicacion.conexion.cerrar();
    servidor = sistema.servidor;

    const respuesta = await fetch(sistema.url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(SOLICITUD_VALIDA),
    });
    const cuerpo = (await respuesta.json()) as {
      numeroOrden: string;
      pago: { urlRedireccion: string };
    };

    expect(respuesta.status).toBe(201);
    expect(cuerpo.numeroOrden).toMatch(/^ORD-/);
    expect(cuerpo.pago.urlRedireccion).toBe('https://pago.simulado/checkout');
    expect(
      aplicacion.conexion.baseDatos.prepare('SELECT COUNT(*) cantidad FROM compras').get(),
    ).toEqual({ cantidad: 1 });
    expect(
      aplicacion.conexion.baseDatos.prepare('SELECT COUNT(*) cantidad FROM entradas').get(),
    ).toEqual({ cantidad: 2 });
    expect(pasarela.llamadas).toEqual([{ numeroOrden: cuerpo.numeroOrden, total: 25000 }]);
    expect(notificador.llamadas).toEqual([]);
  });

  // Toda la cadena real hasta el mail armado: solo se reemplaza la salida SMTP.
  it('con efectivo envía al comprador el mail de confirmación con un QR legible por entrada', async () => {
    const transporte = new TransporteMailFalso();
    const sistema = await crearSistemaDePrueba(
      new NotificadorMail(transporte, 'EcoHarmony Park <ecoharmonypark1@gmail.com>'),
    );
    cerrarBaseDatos = () => sistema.aplicacion.conexion.cerrar();
    servidor = sistema.servidor;

    const respuesta = await fetch(sistema.url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ ...SOLICITUD_VALIDA, formaPago: 'EFECTIVO' }),
    });
    const cuerpo = (await respuesta.json()) as { numeroOrden: string };

    expect(respuesta.status).toBe(201);
    expect(transporte.llamadas).toHaveLength(1);
    const [mail] = transporte.llamadas;
    expect(mail!.para).toBe('visitante@mail.com');
    expect(mail!.asunto).toContain(cuerpo.numeroOrden);
    expect(mail!.adjuntos.map((adjunto) => leerQR(adjunto.contenido))).toEqual([
      `QR-${cuerpo.numeroOrden}-1`,
      `QR-${cuerpo.numeroOrden}-2`,
    ]);
  });

  // Flujo completo con tarjeta: solo se reemplaza la salida SMTP; Mercado Pago es el simulado.
  it('con tarjeta redirige al checkout y envía el mail recién cuando se aprueba el pago', async () => {
    const transporte = new TransporteMailFalso();
    const pasarela = new PasarelaPagoSimulada({
      urlCheckout: RUTA_CHECKOUT_SIMULADO,
      urlRetorno: '/',
    });
    const aplicacion = crearAplicacion({
      ruta: ':memory:',
      pasarela,
      notificador: new NotificadorMail(transporte, 'EcoHarmony Park <ecoharmonypark1@gmail.com>'),
    });
    cerrarBaseDatos = () => aplicacion.conexion.cerrar();
    aplicacion.conexion.baseDatos
      .prepare('INSERT INTO usuarios(email) VALUES (?)')
      .run('visitante@mail.com');
    servidor = crearServidor(
      aplicacion.controlador,
      new CheckoutSimuladoController(pasarela, aplicacion.comprasService, RUTA_PAGO_SIMULADO),
    );
    await new Promise<void>((resolve) => servidor!.listen(0, '127.0.0.1', resolve));
    const direccion = servidor.address();
    if (!direccion || typeof direccion === 'string') throw new Error('Sin puerto.');
    const base = `http://127.0.0.1:${direccion.port}`;

    const compra = await fetch(`${base}/api/compras`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(SOLICITUD_VALIDA),
    });
    const { numeroOrden, pago } = (await compra.json()) as {
      numeroOrden: string;
      pago: { urlRedireccion: string };
    };
    expect(transporte.llamadas).toHaveLength(0);

    const checkout = await fetch(`${base}${pago.urlRedireccion}`);
    expect(checkout.status).toBe(200);
    expect(await checkout.text()).toContain(numeroOrden);

    const pagar = await fetch(
      `${base}${RUTA_PAGO_SIMULADO}?pref_id=PREF-${numeroOrden}&resultado=aprobado`,
      { method: 'POST', redirect: 'manual' },
    );
    expect(pagar.status).toBe(303);
    expect(pagar.headers.get('location')).toBe(
      `/?status=approved&external_reference=${numeroOrden}&preference_id=PREF-${numeroOrden}`,
    );

    expect(transporte.llamadas).toHaveLength(1);
    expect(transporte.llamadas[0]!.adjuntos.map((adjunto) => leerQR(adjunto.contenido))).toEqual([
      `QR-${numeroOrden}-1`,
      `QR-${numeroOrden}-2`,
    ]);
    const consulta = await fetch(`${base}/api/compras/${numeroOrden}`);
    await expect(consulta.json()).resolves.toMatchObject({
      numeroOrden,
      fechaVisita: '2026-10-20',
      estadoPago: 'APROBADO',
    });
  });
});
