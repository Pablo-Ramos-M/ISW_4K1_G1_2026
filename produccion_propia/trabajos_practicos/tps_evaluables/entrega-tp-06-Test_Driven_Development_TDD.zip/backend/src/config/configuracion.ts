// Editar estos valores para ejecutar el backend localmente.
export const configuracion = {
  baseDatos: {
    ruta: './bd/data/parque.sqlite',
  },
  servidor: {
    // En Docker se usa HOST=0.0.0.0 para aceptar conexiones de otros contenedores.
    host: process.env.HOST ?? '127.0.0.1',
    puerto: 3000,
  },
  simulacion: {
    // back_url a la que vuelve el checkout simulado de Mercado Pago. Es relativa: sirve igual
    // en Vite (desarrollo) y en nginx (Docker), que pasan /api al backend.
    urlRetornoMercadoPago: '/',
    emailUsuarioRegistrado: process.env.EMAIL_DEMO ?? 'visitante@mail.com',
  },
  // Las credenciales se leen del .env de la raíz (ver .env.example).
  mail: {
    host: process.env.SMTP_HOST,
    puerto: Number(process.env.SMTP_PUERTO ?? 587),
    usuario: process.env.SMTP_USUARIO,
    clave: process.env.SMTP_CLAVE,
    remitente: process.env.MAIL_REMITENTE ?? 'EcoHarmony Park <ecoharmonypark1@gmail.com>',
  },
} as const;
